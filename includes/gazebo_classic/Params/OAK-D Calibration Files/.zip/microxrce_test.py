import rclpy
import numpy as np
from scipy.spatial.transform import Rotation as R
from rclpy.node import Node
from rclpy.clock import Clock
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy
from geometry_msgs.msg import Twist

from geometry_msgs.msg import TransformStamped, Twist
from tf2_ros import TransformBroadcaster
from px4_msgs.msg import OffboardControlMode
from px4_msgs.msg import TrajectorySetpoint
from px4_msgs.msg import VehicleStatus
from px4_msgs.msg import VehicleCommand
from px4_msgs.msg import VehicleOdometry 
from nav_msgs.msg import Odometry
from sensor_msgs.msg import CameraInfo
import time
import argparse

def str2bool(v):
    if isinstance(v, bool):
       return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--OffboardControllEnable", type=str2bool , default=str2bool(True), help='Enabling offboard controll or just pass odometry')
    parser.add_argument("--TakeoffHeight", default=1.5, type=float, help='TakeOff flight height')
    # parser.add_argument("--OdomTopic", default='/odom', type=str, help='Odometry topic')
    args = parser.parse_args()
    return args

camera_info = "/camera/camera_info"

class OffboardControll(Node):

    def __init__(self):
        super().__init__('minimal_publisher')

        args = parse_args()

        qos_profile1 = QoSProfile(
            reliability=QoSReliabilityPolicy.RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT,
            durability=QoSDurabilityPolicy.RMW_QOS_POLICY_DURABILITY_VOLATILE,
            history=QoSHistoryPolicy.RMW_QOS_POLICY_HISTORY_KEEP_LAST,
            depth=1
        )

        qos_profile2 = QoSProfile(
            reliability=QoSReliabilityPolicy.RMW_QOS_POLICY_RELIABILITY_BEST_EFFORT,
            durability=QoSDurabilityPolicy.RMW_QOS_POLICY_DURABILITY_TRANSIENT_LOCAL,
            history=QoSHistoryPolicy.RMW_QOS_POLICY_HISTORY_KEEP_LAST,
            depth=1
        )

        # Create Subscribtions nodes
        self.subscriber_vehicle_status = self.create_subscription(VehicleStatus,'/fmu/out/vehicle_status',self.vehicle_status_callback,qos_profile1)
        self.subscriber_vio_odometry = self.create_subscription(Odometry,'/odom',self.slam_odom_callback,qos_profile1)
        self.subscriber_cmd_vel = self.create_subscription(Twist,'/cmd_vel',self.cmd_vel_callback,10)
        self.subscriber_camera_timestamp = self.create_subscription(CameraInfo,camera_info,self.timestamp_update,qos_profile1)
        self.subscriber_vehicle_odometry = self.create_subscription(VehicleOdometry,'/fmu/out/vehicle_odometry',self.vehicle_odometry_callback,qos_profile1)

        # Create publications nodes
        self.publisher_offboard_control_mode = self.create_publisher(OffboardControlMode, '/fmu/in/offboard_control_mode', qos_profile2)
        self.publisher_trajectory_setpoint = self.create_publisher(TrajectorySetpoint, '/fmu/in/trajectory_setpoint', qos_profile2)
        self.publisher_vehicle_command = self.create_publisher(VehicleCommand, '/fmu/in/vehicle_command', qos_profile2)
        self.publiser_slam_odom = self.create_publisher(VehicleOdometry,'/fmu/in/vehicle_visual_odometry',qos_profile2)
        self.recovery_node_publisher = self.create_publisher(Twist, '/cmd_vel', 10)

        # define timer for publishing cmd_vel
        self.timer_peroid = 0.05
        self.timer = self.create_timer(self.timer_peroid, self.timer_callback)

        # Define initial parameters
        self._logger.info("initiated the offboard controll node")
        self.tf_broadcaster = TransformBroadcaster(self)
        self.vio_odometry = Odometry()
        self.vehilcle_odometry_zero = None
        # self.T_BvBp = np.array([[0, 1, 0], [1, 0, 0], [0, 0, -1]])
        self.T_BvBp = np.array([[1, 0, 0], [0, -1, 0], [0, 0, -1]])
        self.T_BpRv_zero = np.transpose(np.array([[0, 1, 0], [1, 0, 0], [0, 0, -1]]))
        self.T_RpBp_zero = R.from_quat([0, 0, 0, 1]).as_matrix()
        self.T_RpRv = None
        self.timestamp = None
        self.arm_state = 1
        self.take_off_ground = False
        self.takeOffHeight = -args.TakeoffHeight
        self.not_published_before = True
        self.takeOff_complete = False
        self.nav_state = VehicleStatus.NAVIGATION_STATE_MAX
        self.OffboardControllEnable = args.OffboardControllEnable
        self.IS_ODOM_LOST = False
        self.cmd_vel_timestamp = Clock().now()
        self.cmd_vel_msg = Twist()

    def timestamp_update(self, msg):
        self.timestamp = msg.header.stamp

    def slam_odom_callback(self, msg):
        print(msg)
        # update the vio properties
        if msg.pose.pose.orientation.x != 0 \
            or msg.pose.pose.orientation.y != 0 \
            or msg.pose.pose.orientation.z != 0 \
            or msg.pose.pose.orientation.w != 0:
            self.vio_odometry = msg
            self.IS_ODOM_LOST = False
        else:
            self.IS_ODOM_LOST = True

        # activating recovery mode if ODOM is lost

        self.vio_time_stamp = int(Clock().now().nanoseconds / 1000)

        # print the comparision of slam and vehicle odomtery
        if self.take_off_ground:
            print('vehicle odometry is : ', self.vehicle_odometry.position[2] , 'VIO odometry is : ', -self.vio_odometry.pose.pose.position.z
            , 'error in fusion is : ', abs(self.vehicle_odometry.position[2] + self.vio_odometry.pose.pose.position.z))

        # publish take of setpoint_trajectory msg
        if self.take_off_ground and self.OffboardControllEnable:
            if self.not_published_before:
                print("publishing offborad command before takeoff")
                self.change_to_offboard()
                self.publish_setpoints_before_chage_to_offborad()
                self.not_published_before = False
            self.takeOff(self.vehicle_odometry.position[2])

        
        q = np.array([self.vio_odometry.pose.pose.orientation.x, self.vio_odometry.pose.pose.orientation.y, self.vio_odometry.pose.pose.orientation.z, self.vio_odometry.pose.pose.orientation.w], dtype=np.float32)
        self.T_RvBv = R.from_quat(q).as_matrix()
        x = np.dot(self.T_RpBp_zero, np.transpose(self.T_BvBp))
        y = np.dot(x, self.T_RvBv)
        self.T_RpBp = np.dot(y, self.T_BvBp)
        self.T_RpRv = np.dot(self.T_RpBp_zero, self.T_BvBp)
        self.callback_loop()

    def vehicle_status_callback(self, msg):
        # TODO: handle NED->ENU transformation
        # print("NAV_STATUS: ", msg.nav_state)

        # update navigation status
        self.nav_state = msg.nav_state

        # update arm state
        self.arm_state = msg.arming_state

        # arm or takeoff the drone and update the take_off condition
        # based on take_off_complete variable
        if self.arm_state == 1:
            self.arm()
        if (self.arm_state == 2) :
            if not self.takeOff_complete:
                self.take_off_ground = True
                pass

    def arm(self):
        if self.OffboardControllEnable:
            vehicle_command = VehicleCommand()
            vehicle_command.param1 = 1.0
            vehicle_command.command = VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM
            vehicle_command.target_system = 1
            vehicle_command.target_component = 1
            vehicle_command.source_system = 1
            vehicle_command.source_component = 1
            vehicle_command.from_external = True
            vehicle_command.timestamp = int(Clock().now().nanoseconds / 1000) 
            self.publisher_vehicle_command.publish(vehicle_command)
            print("vehicle armed properly")

    def takeOff(self, z):
        if self.OffboardControllEnable:
            print("takeing off the ground.")
            if (self.takeOffHeight - z) < -0.1 and self.take_off_ground:
                offboard_msg = OffboardControlMode()
                time_stamp = int(Clock().now().nanoseconds / 1000)
                offboard_msg.timestamp = time_stamp
                offboard_msg.position=True
                offboard_msg.velocity=False
                self.publisher_offboard_control_mode.publish(offboard_msg)
                if self.nav_state != VehicleStatus.NAVIGATION_STATE_OFFBOARD:
                    self.change_to_offboard()
                if self.nav_state == VehicleStatus.NAVIGATION_STATE_OFFBOARD:
                    trajectory_msg = TrajectorySetpoint()
                    trajectory_msg.timestamp = time_stamp
                    trajectory_msg.position[0] = 0.0
                    trajectory_msg.position[1] = 0.0
                    trajectory_msg.position[2] = self.takeOffHeight
                    trajectory_msg.velocity[0] = float('nan')
                    trajectory_msg.velocity[1] = float('nan')
                    trajectory_msg.velocity[2] = float('nan')
                    trajectory_msg.yaw = float('nan')
                    trajectory_msg.yawspeed = 0.0
                    self.publisher_trajectory_setpoint.publish(trajectory_msg)
            elif (self.takeOffHeight - z) > 0.1 and self.take_off_ground:
                offboard_msg = OffboardControlMode()
                time_stamp = int(Clock().now().nanoseconds / 1000)
                offboard_msg.timestamp = time_stamp
                offboard_msg.position=True
                offboard_msg.velocity=False
                self.publisher_offboard_control_mode.publish(offboard_msg)
                if self.nav_state != VehicleStatus.NAVIGATION_STATE_OFFBOARD:
                    self.change_to_offboard()
                if self.nav_state == VehicleStatus.NAVIGATION_STATE_OFFBOARD:
                    trajectory_msg = TrajectorySetpoint()
                    trajectory_msg.timestamp = time_stamp
                    trajectory_msg.position[0] = 0.0
                    trajectory_msg.position[1] = 0.0
                    trajectory_msg.position[2] = -self.takeOffHeight
                    trajectory_msg.velocity[0] = float('nan')
                    trajectory_msg.velocity[1] = float('nan')
                    trajectory_msg.velocity[2] = float('nan')
                    trajectory_msg.yaw = float('nan')
                    trajectory_msg.yawspeed = 0.0
                    self.publisher_trajectory_setpoint.publish(trajectory_msg)
            else:
                self.take_off_ground = False
                self.takeOff_complete = True
                self.current_goal = self.vehicle_odometry
                print("takeOff completed successfully!!")
    
    def change_to_offboard(self):
        if self.OffboardControllEnable:
            vehicle_command = VehicleCommand()
            vehicle_command.param1 = 1.0
            vehicle_command.param2 = 6.0
            vehicle_command.command = VehicleCommand.VEHICLE_CMD_DO_SET_MODE
            vehicle_command.target_system = 1
            vehicle_command.target_component = 1
            vehicle_command.from_external = True
            vehicle_command.timestamp = int(Clock().now().nanoseconds / 1000)
            self.publisher_vehicle_command.publish(vehicle_command) 

    def publish_setpoints_before_chage_to_offborad(self):
        if self.OffboardControllEnable:
            for i in range(100):
                offboard_msg = OffboardControlMode()
                time_stamp = int(Clock().now().nanoseconds / 1000)
                offboard_msg.timestamp = time_stamp
                offboard_msg.position=True
                offboard_msg.velocity=True
                self.publisher_offboard_control_mode.publish(offboard_msg)
                if self.nav_state == VehicleStatus.NAVIGATION_STATE_OFFBOARD:
                    trajectory_msg = TrajectorySetpoint()
                    trajectory_msg.timestamp = time_stamp
                    trajectory_msg.position[0] = float('nan')
                    trajectory_msg.position[1] = float('nan')
                    trajectory_msg.position[2] = float('nan')
                    trajectory_msg.velocity[0] = 0.0
                    trajectory_msg.velocity[1] = 0.0
                    trajectory_msg.velocity[2] = 0.0
                    trajectory_msg.yaw = float('nan')
                    trajectory_msg.yawspeed = 0.0
                    self.publisher_trajectory_setpoint.publish(trajectory_msg)

    def vehicle_odometry_callback(self, msg):
        
        # first get the T_RpBp_zero
        if self.vehilcle_odometry_zero is None:
            self.vehilcle_odometry_zero = msg
            self.fmu_q_zero =np.array([self.vehilcle_odometry_zero.q[1], self.vehilcle_odometry_zero.q[2], self.vehilcle_odometry_zero.q[3], self.vehilcle_odometry_zero.q[0]])
            self.T_RpBp_zero = R.from_quat(self.fmu_q_zero).as_matrix()
            print("T_RpBp_zero is going to set equal to : \n", self.T_RpBp_zero)
        else:
            pass
        
        # then publish update vehicle odometry variable
        self.vehicle_odometry = msg
        self.fmu_q =np.array([self.vehicle_odometry.q[1], self.vehicle_odometry.q[2], self.vehicle_odometry.q[3], self.vehicle_odometry.q[0]])
        self.T_RpBp_fusion = R.from_quat(self.fmu_q).as_matrix()

    def callback_loop(self):
        if (self.T_RpRv is not None) and (not np.array_equal(self.T_RpBp_zero, np.ones_like(self.T_RpBp_zero))):
            self.rtps_odometry_in = VehicleOdometry()
            self.rtps_odometry_in.timestamp = self.vio_time_stamp
            self.rtps_odometry_in.timestamp_sample = self.vio_time_stamp
            self.rtps_odometry_in.pose_frame = 0
            self.r_rv = np.array([self.vio_odometry.pose.pose.position.x, self.vio_odometry.pose.pose.position.y, self.vio_odometry.pose.pose.position.z])
            self.r_rp = np.dot(self.T_RpRv, np.transpose(self.r_rv))
            self.rtps_odometry_in.position[0] = self.r_rp[0]
            self.rtps_odometry_in.position[1] = self.r_rp[1]
            self.rtps_odometry_in.position[2] = self.r_rp[2]
            q = R.from_matrix(self.T_RpBp).as_quat()
            self.rtps_odometry_in.q = np.array([q[3], q[0], q[1], q[2]], dtype=np.float32)
            self.rtps_odometry_in.velocity_frame = 0
            self.v_rv = np.array([self.vio_odometry.twist.twist.linear.x, self.vio_odometry.twist.twist.linear.y, self.vio_odometry.twist.twist.linear.z])
            self.v_rp = np.dot(self.T_RpRv, np.transpose(self.v_rv))
            self.rtps_odometry_in.velocity[0] = self.v_rp[0]
            self.rtps_odometry_in.velocity[1] = self.v_rp[1]
            self.rtps_odometry_in.velocity[2] = self.v_rp[2]
            self.angular_rv = np.array([self.vio_odometry.twist.twist.angular.x, self.vio_odometry.twist.twist.angular.y, self.vio_odometry.twist.twist.angular.z])
            self.angular_rp = np.dot(self.T_RpRv, np.transpose(self.angular_rv))
            self.rtps_odometry_in.angular_velocity[0] = self.angular_rp[0]
            self.rtps_odometry_in.angular_velocity[1] = self.angular_rp[1]
            self.rtps_odometry_in.angular_velocity[2] = self.angular_rp[2]
            self.rtps_odometry_in.reset_counter = 4
            self.publiser_slam_odom.publish(self.rtps_odometry_in)

    def cmd_vel_callback(self, msg):
        self.cmd_vel_timestamp = Clock().now()
        if self.IS_ODOM_LOST:
            self.cmd_vel_msg = Twist()
            self.cmd_vel_msg.angular.z = 0.2
        else:
            self.cmd_vel_msg = msg
    
    def timer_callback(self):
        if self.OffboardControllEnable and self.takeOff_complete: 
            # transforming cmd_vel to NED frame
            self.linear_Bp = np.array([self.cmd_vel_msg.linear.x, -self.cmd_vel_msg.linear.y, -self.cmd_vel_msg.linear.z], dtype=np.float32)
            self.angular_Bp = np.array([self.cmd_vel_msg.angular.x, -self.cmd_vel_msg.angular.y, -self.cmd_vel_msg.angular.z], dtype=np.float32)
            self.linear_Rp = np.dot(self.T_RpBp_fusion, np.transpose(self.linear_Bp))
            self.angular_Rp = np.dot(self.T_RpBp_fusion, np.transpose(self.angular_Bp))

            # publish the transformed cmd_vel to autopilot_rtps if recived cmd_vel recently
            if (abs((self.cmd_vel_timestamp.seconds_nanoseconds()[0]+ \
                self.cmd_vel_timestamp.seconds_nanoseconds()[1]/10e8) - \
                (Clock().now().seconds_nanoseconds()[0]+ \
                Clock().now().seconds_nanoseconds()[1]/10e8)) < 0.5):
                self.current_goal = self.vehicle_odometry
                offboard_msg = OffboardControlMode()
                time_stamp = int(Clock().now().nanoseconds / 1000)
                offboard_msg.timestamp = time_stamp
                offboard_msg.position=True
                offboard_msg.velocity=True
                self.publisher_offboard_control_mode.publish(offboard_msg)
                if self.nav_state == VehicleStatus.NAVIGATION_STATE_OFFBOARD:
                    trajectory_msg = TrajectorySetpoint()
                    trajectory_msg.timestamp = time_stamp
                    trajectory_msg.position[0] = float('nan')
                    trajectory_msg.position[1] = float('nan')
                    trajectory_msg.position[2] = self.takeOffHeight
                    trajectory_msg.velocity[0] = self.linear_Rp[0]
                    trajectory_msg.velocity[1] = self.linear_Rp[1]
                    trajectory_msg.velocity[2] = float('nan')
                    trajectory_msg.yaw = float('nan')
                    trajectory_msg.yawspeed = self.angular_Rp[2]
                    print("publishing trajectory setpoint to px4 : ", trajectory_msg)
                    self.publisher_trajectory_setpoint.publish(trajectory_msg)

            # publish the position controll command to autopilot_rtps if not recived cmd_vel recently
            elif (abs((self.cmd_vel_timestamp.seconds_nanoseconds()[0]+ \
                  self.cmd_vel_timestamp.seconds_nanoseconds()[1]/10e8) - \
                  (Clock().now().seconds_nanoseconds()[0]+ \
                  Clock().now().seconds_nanoseconds()[1])/10e8) >= 0.5):
                offboard_msg = OffboardControlMode()
                time_stamp = int(Clock().now().nanoseconds / 1000)
                offboard_msg.timestamp = time_stamp
                offboard_msg.position=True
                offboard_msg.velocity=False
                self.publisher_offboard_control_mode.publish(offboard_msg)
                if self.nav_state == VehicleStatus.NAVIGATION_STATE_OFFBOARD:
                    trajectory_msg = TrajectorySetpoint()
                    trajectory_msg.timestamp = time_stamp
                    trajectory_msg.position[0] = self.current_goal.position[0]
                    trajectory_msg.position[1] = self.current_goal.position[1]
                    trajectory_msg.position[2] = self.current_goal.position[2]
                    trajectory_msg.velocity[0] = float('nan')
                    trajectory_msg.velocity[1] = float('nan')
                    trajectory_msg.velocity[2] = float('nan')
                    trajectory_msg.yaw = float('nan')
                    trajectory_msg.yawspeed = float('nan')
                    print("publishing position controll setpoint to px4 : ", trajectory_msg)
                    self.publisher_trajectory_setpoint.publish(trajectory_msg)


# if __name__ == "__main__":
rclpy.init(args=None)

time.sleep(1)
offboard_controll = OffboardControll()


rclpy.spin(offboard_controll)

offboard_controll.destroy_node()
rclpy.shutdown()
